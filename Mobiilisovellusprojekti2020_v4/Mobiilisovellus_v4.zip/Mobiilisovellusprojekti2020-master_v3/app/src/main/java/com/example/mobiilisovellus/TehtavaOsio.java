package com.example.mobiilisovellus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TehtavaOsio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tehtava_osio);
    }
}
