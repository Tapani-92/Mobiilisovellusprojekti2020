package com.example.mobiilisovellus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class tehtavan_muokkaus extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tehtavan_muokkaus);
    }
}
